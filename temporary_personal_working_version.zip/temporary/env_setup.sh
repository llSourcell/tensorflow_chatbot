echo 'export PYTHONPATH=$PYTHONPATH:$PWD' >> ~/.bashrc
